<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    body{
      font-family:"Calibri", sans-serif;
    }
  </style>
</head>
<body>
  
  <table style="padding-left:30px;">
		<tr>
			<td style="width:30%;">
				<img src="{{asset('assets/assets/img/proposal/page-2.jpg')}}" style="position:relative;width:100%;height:100%;">
			</td>
			<td style="wdith:70%;">
        <div style="position: absolute;top:20px; font-size:20px;">
          To				
			  
				<p><b>{{$institute_name}}</b>
				<br>
				<br>
				</p>	
				
			 
				<p>{{$institute_address}}
				<br>
        <br>
				</p>			
			  
				<p><b>Kind Attn: {{$inst_contact_person}}</b>
          <br>
          <br>
				</p>	
				
				
				<br>
				
				<h1>
				<br>
        <br>
        <br>
        <br>
        <br>
        <br>
				<br>Introduction</h1>
				
				
				<p>
				<br>
				<br><b>Sikshapedia.com</b> is a unique online portal for those seeking to pursue higher education,
				looking for the best colleges within India and abroad. It is a distinctive search engine specially designed for education specialists, students, scholars, teachers, professors,  and parents. It is an informational channel to connect you with the world of education. At Sikshapedia.com you can find the best universi6es, best colleges, top courses, and upcoming exams of all subjects.</p>
				
				<br>
        <br>
				<p><b>Sikshapedia.com</b> provides a crisp and cropped list according to your needs. We have listed the best universities to provide quick informa6on. For your convenience, you can also find informa6on on top universities and top courses according to the top educaton hubs and cities of India and abroad. You can easily select a course or browse information about the best university in different metropolitan cities of India which are helpful especially to those that are from rural, urban, and other backward areas to fly with their wings at our portal.</p>
				
				
        </div>
				
			
			</td>
		</tr>
	</table>
    
</body>
</html>
