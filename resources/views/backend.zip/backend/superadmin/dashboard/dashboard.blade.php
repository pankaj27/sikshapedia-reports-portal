@extends('backend.superadmin.layout.app')
@section('title','Dashboard | ncriptech website CMS')

@section('content')

<div class="mainCon">
	<div class="d-flex flex-md-row flex-sm-column  justify-content-md-between pb-4 ">
	<h2 class="heading">Welcome to <span>Sikshapedia Superadmin</span> Portal</h2>
	</div>
	<div class="dashboardNotiwrap">

		<div class="superadminDashboardNotification">
			
		</div>


		<div class="superadminDashboardNotification">
			
		</div>


		<div class="superadminDashboardNotification">
			
		</div>


        <div class="superadminDashboardNotification">
			
		</div>


		<div class="superadminDashboardNotification">
			
		</div>


		<div class="superadminDashboardNotification">
			
		</div>
		

	</div>
</div>
   

@endsection